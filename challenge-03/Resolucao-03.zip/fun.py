def verifica_string(valor):
  if type(valor) is not str:
    return False
  else:
    return True
